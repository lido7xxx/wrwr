import os
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup


API_ID = int("20551716")
API_HASH = "564355da021dc5739c01f33fb015eaf1"
Bots = []
off =None
ch = "VeGaOne" 
DEVS = ["ToxVe", "TopVeGa"] 
@Client.on_message(filters.private)
async def me(client, message):
   if off: 
    if not message.from_user.username in DEVS:
     return await message.reply_text("المصنع معطل")
   try:
      await client.get_chat_member(ch, message.from_user.id)
   except:
      return await message.reply_text(f"يجب ان تشترك ف قناة السورس أولا \n https://t.me/{ch}", disable_web_page_preview=True)
   message.continue_propagation()

@Client.on_message(filters.command("start") & filters.private)
async def start(client, message):
   if message.from_user.username in DEVS:
     kep = ReplyKeyboardMarkup([["صنع بوت", "حذف بوت"], ["البوتات المصنوعه"], ["تعطيل المجاني", "تفعيل المجاني"], ["السورس"]], resize_keyboard=True)
     return await message.reply_text("اهلا بيك ف مصنع بوتات سونك ميوزك", reply_markup=kep)
   kep = ReplyKeyboardMarkup([["صنع بوت", "حذف بوت"], ["السورس"]], resize_keyboard=True)
   await message.reply_text("اهلا بيك ف مصنع بوتات يوسف ميوزك", reply_markup=kep)

@Client.on_message(filters.command(["السورس"], ""))
async def vegastart(client: Client, message):
    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("𝙶𝚁𝙾𝚄𝙿️", url=f"https://t.me/vegaone"),
                InlineKeyboardButton("𝚂𝙾𝚄𝚁𝙲𝙴️", url=f"https://t.me/vegaone"),
            ],
            [
                 InlineKeyboardButton(f"مطور السورس", url=f"https://t.me/ToxVeGa")
            ]
        ]
    )

    await message.reply_photo(
        photo="https://graph.org/file/7e05de11143969215a815.jpg",
        caption="𝗬𝗼𝘂𝘀𝗲𝗳 𝙎𝙊𝙐𝙍𝘾𝙀",
        reply_markup=keyboard,
    )
@Client.on_message(filters.command(["تفعيل المجاني", "تعطيل المجاني"], "") & filters.private)
async def onoff(client, message):
  if not message.from_user.username in DEVS:
    return
  global off
  if message.text == "تفعيل المجاني":
    off = None
    return await message.reply_text("تم تفعيل المجاني بنجاح .")
  else:
    off = True
    await message.reply_text("تم تعطيل المجاني بنجاح .")
@Client.on_message(filters.command("صنع بوت", "") & filters.private)
async def vegamaked(client, message):
  if not message.from_user.username in DEVS:
    for x in Bots:
        if x[1] == message.from_user.id:
          return await message.reply_text("لقد قمت بصنع بوت من قبل . ")
  try:
    ask = await client.ask(message.chat.id, "ارسل توكن البوت", timeout=300)
  except:
      return
  TOKEN = ask.text
  try:
    ask = await client.ask(message.chat.id, "ارسل كود الجلسه", timeout=300)
  except:
      return
  SESSION = ask.text
  try:
    ask = await client.ask(message.chat.id, "ارسل الان ايدي مجموعة السجل وتاكد من تشغيل مكالمه صوتيه", timeout=300)
  except:
      return
  LOG = ask.text
  Dev = message.from_user.id
  if message.from_user.username in DEVS:
    try:
       ask = await client.ask(message.chat.id, "ارسل ايدي المطور", timeout=300)
    except:
      return
    try:
      Dev = int(ask.text)
    except:
      return await message.reply_text("قم بارسال الايدي بشكل صحيح")
  bot = Client(f"BOT:{TOKEN}", api_id=API_ID, api_hash=API_HASH, bot_token=TOKEN)
  user = Client(f"user:{TOKEN}",api_id=API_ID, api_hash=API_HASH, session_string=str(SESSION))
  try:
    await bot.start()
    username = await bot.get_me()
    username = username.username
    await bot.stop()
    await user.start()
    await user.stop()
  except:
    return await message.reply_text("تاكد من التوكن أو الجلسة")
  os.system(f"rm BOT:{TOKEN}")
  os.system(f"rm user:{TOKEN}")
  id = username
  for x in Bots:
        if x[0] == id:
          return await message.reply_text("لقد قمت بصنع هذا البوت من قبل . ")
  os.system(f"cp -a VeGaSouRce VeGaMaKed/{id}")
  env = open(f"VeGaMaKed/{id}/.env", "w+", encoding="utf-8")
  x = f'BOT_TOKEN = {TOKEN}\nSTRING_SESSION = {SESSION}\nOWNER_ID = {Dev}\nMONGO_DB_URI = mongodb+srv://VeGaMusIc:VeGaOne@cluster0.nf0ml.mongodb.net/?retryWrites=true&w=majority\nLOGGER_ID = {LOG}'
  env.write(x)
  env.close()
  os.system(f"cd VeGaMaKed/{id} && screen -d -m -S {id} python3 -m VeGaMusic")
  oo = [id, Dev]
  Bots.append(oo)
  await message.reply_text("تم صنع بوتك بنجاح 🌿♥️")

@Client.on_message(filters.command("حذف بوت", "") & filters.private)
async def vegadeletbot(client, message):
   if not message.from_user.username in DEVS:
     for x in Bots:
         bot = x[0]
         if x[1] == message.from_user.id:       
           os.system(f"sudo rm -fr VeGaMaKed/{bot}")
           os.system(f"screen -XS {bot} quit")
           Bots.remove(x)
           return await message.reply_text("تم حذف بوتك من المصنع .")
     return await message.reply_text("لم تقم بصنع بوتات")
   try:
      bot = await client.ask(message.chat.id," ارسل يوزر البوت", timeout=200)
   except:
      return
   bot = bot.text.replace("@", "")
   for x in Bots:
       if x[0] == bot:
          Bots.remove(x)
   os.system(f"sudo rm -fr VeGaMaKed/{bot}")
   os.system(f"screen -XS {bot} quit")
   await message.reply_text("تم حذف البوت بنجاح")


@Client.on_message(filters.command("البوتات المصنوعه", ""))
async def botvega(client, message):
  if not message.from_user.username in DEVS:
   return
  o = 0
  text = "قايمه البوتات\n"
  for x in Bots:
      o += 1
      text += f"{o}- @{x[0]}\n"
  if o == 0:
    return await message.reply_text("لا يوجد بوتات مصنوعه")
  await message.reply_text(text)
