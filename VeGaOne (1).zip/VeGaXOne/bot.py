from pyrogram import Client, idle
from pyromod import listen



bot = Client(
    "VeGaMousic",
    api_id=20551716,
    api_hash="564355da021dc5739c01f33fb015eaf1",
    bot_token="توكن البوت", 
    plugins=dict(root="VeGaMeKer")
    ) 

async def start_VeGabot():
    print("تم تشغيل الصانع بنجاح..💗")
    await bot.start()
    ToxVeGa = "ToxVeGa"
    try:
        await bot.send_message(ToxVeGa, "**تم تشغيل الصانع بنجاح ...🥀**")
    except:
        pass
    await idle()
